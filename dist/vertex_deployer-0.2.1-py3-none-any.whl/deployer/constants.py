PIPELINE_ROOT_PATH = "vertex/pipelines"
CONFIG_ROOT_PATH = "vertex/configs"

DEFAULT_SCHEDULER_TIMEZONE = "Europe/Paris"
DEFAULT_LOCAL_PACKAGE_PATH = "vertex/pipelines/compiled_pipelines"
DEFAULT_TAGS = ["latest"]

TEMP_LOCAL_PACKAGE_PATH = ".vertex-deployer-temp"


PIPELINE_MINIMAL_TEMPLATE = """import kfp.dsl


@kfp.dsl.pipeline(name="{pipeline_name}")
def pipeline():
    pass

"""

PYTHON_CONFIG_TEMPLATE = """from kfp.dsl import Artifact, Dataset, Input, Output, Metrics

parameter_values = {}
input_artifacts = {}

"""
